import setuptools
setuptools.setup(name='paho',
                packages=setuptools.find_packages(),
                version='1.3.1.1'
)
