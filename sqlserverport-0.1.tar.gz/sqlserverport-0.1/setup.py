import setuptools
setuptools.setup(name='sqlserverport',
                packages=setuptools.find_packages(),
                version='0.1'
)

