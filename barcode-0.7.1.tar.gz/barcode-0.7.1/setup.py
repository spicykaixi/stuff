import setuptools
setuptools.setup(name='barcode',
                 packages=setuptools.find_packages(),
                 version='0.7.1',
				 include_package_data=True
)
