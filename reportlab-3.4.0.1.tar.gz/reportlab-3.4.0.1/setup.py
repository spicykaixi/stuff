import setuptools
setuptools.setup(name='reportlab',
                packages=setuptools.find_packages(),
                version='3.4.0.1',
                include_package_data=True
)
